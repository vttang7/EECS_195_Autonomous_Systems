#!/usr/bin/env python3

import rospy
import math
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

class SwimToGoal:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('swim_to_goal')
        self.pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        self.pose_sub = rospy.Subscriber('/turtle1/pose', Pose, self.pose_callback)
        self.rate = rospy.Rate(10) #10 Hz
        
    # Control parameters
        self.K_linear = 1.5  # Proportional constant for linear velocity
        self.K_angular = 4.0  # Proportional constant for angular velocity
        self.position_tolerance = 0.5  # Distance threshold to consider goal reached
        
        # Turtle state
        self.current_pose = None
        self.goal_x = None
        self.goal_y = None
        
    def pose_callback(self, data):
        """Update current turtle position"""
        self.current_pose = data
        
    def get_user_input(self):
        """Get goal coordinates from user"""
        print("\nEnter goal coordinates:")
        self.goal_x = float(input("x: "))
        self.goal_y = float(input("y: "))
        print(f"Moving to ({self.goal_x}, {self.goal_y})")
        
    def calculate_errors(self):
        """Compute position and angle errors"""
        if self.current_pose is None:
            return None, None
            
        # Position error (Euclidean distance)
        error_x = self.goal_x - self.current_pose.x
        error_y = self.goal_y - self.current_pose.y
        position_error = math.sqrt(error_x**2 + error_y**2)
        
        # Angle error (difference between current and desired heading)
        desired_angle = math.atan2(error_y, error_x)
        angle_error = desired_angle - self.current_pose.theta
        
        # Normalize angle error to [-π, π]
        angle_error = math.atan2(math.sin(angle_error), math.cos(angle_error))
        
        return position_error, angle_error
        
    def control_loop(self):
        rate = rospy.Rate(10)  # 10Hz
        
        while not rospy.is_shutdown():
            if self.current_pose is None:
                rate.sleep()
                continue
                
            # Get new goal if none set
            if self.goal_x is None or self.goal_y is None:
                self.get_user_input()
                continue
                
            # Calculate errors
            pos_err, ang_err = self.calculate_errors()
            
            # Check if goal reached
            if pos_err < self.position_tolerance:
                print("Goal reached!")
                self.goal_x = None
                self.goal_y = None
                self.stop_turtle()
                continue
                
            # Calculate and publish velocities
            cmd = Twist()
            cmd.linear.x = self.K_linear * pos_err
            cmd.angular.z = self.K_angular * ang_err
            self.pub.publish(cmd)
            
            rate.sleep()
            
    def stop_turtle(self):
        """Stop the turtle's movement"""
        cmd = Twist()
        cmd.linear.x = 0
        cmd.angular.z = 0
        self.pub.publish(cmd)

if __name__ == '__main__':
    try:
        controller = SwimToGoal()
        controller.control_loop()
    except rospy.ROSInterruptException:
        pass