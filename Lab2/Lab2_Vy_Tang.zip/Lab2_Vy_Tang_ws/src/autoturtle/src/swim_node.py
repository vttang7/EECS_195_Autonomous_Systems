#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import math
import random

class SwimNode:
    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('swim_node')
        self.pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        self.rate = rospy.Rate(10) #10 Hz 
        
        # Initialize with Gaussian random velocities (positive only)
        self.linear_velocity = abs(random.gauss(1.5, 0.5)) 
        self.angular_velocity = abs(random.gauss(1.5, 0.5))
        
        # Direction control variables
        self.direction = 1
        self.switch = 2 * (math.pi / self.angular_velocity)
        self.last_switch_time = rospy.Time.now()
    
    def motion_eight(self):
        vel_msg = Twist()
        
        while not rospy.is_shutdown():
            current_time = rospy.Time.now()
            elapsed = (current_time - self.last_switch_time).to_sec()
            
            # Switch direction when interval elapsed
            if elapsed >= self.switch - 0.01:  # small buffer
                self.direction *= -1
                self.last_switch_time = current_time
            
            # Set velocities
            vel_msg.linear.x = self.linear_velocity
            vel_msg.angular.z = self.direction * self.angular_velocity
            
            self.pub.publish(vel_msg)
            self.rate.sleep()
            
if __name__ == '__main__':
    try:
        node = SwimNode()
        node.motion_eight()
    except rospy.ROSInterruptException:
        pass