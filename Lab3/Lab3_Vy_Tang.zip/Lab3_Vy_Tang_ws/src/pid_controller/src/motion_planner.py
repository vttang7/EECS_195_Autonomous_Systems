#!/usr/bin/env python3
import rospy
import math
from std_msgs.msg import Float64MultiArray
from nav_msgs.msg import Odometry

class MotionPlanner:
    def __init__(self):
        rospy.init_node('motion_planner')
        
        # Publishers and Subscribers
        self.pose_publisher = rospy.Publisher('/reference_pose', Float64MultiArray, queue_size=10)
        rospy.Subscriber('/odom', Odometry, self.odom_callback)
        
        # State variables
        self.current_pose = {'x': 0.0, 'y': 0.0, 'yaw': 0.0}
        self.target_pose = {'x': 0.0, 'y': 0.0, 'yaw': 0.0, 'mode': 0}
        self.goal_reached = True
        self.rate = rospy.Rate(10)  # 10Hz control loop

    def odom_callback(self, msg):
        """Callback for Odometry messages to update current pose"""
        self.current_pose['x'] = msg.pose.pose.position.x
        self.current_pose['y'] = msg.pose.pose.position.y
        self.current_pose['yaw'] = self.quaternion_to_yaw(msg.pose.pose.orientation)

    @staticmethod
    def quaternion_to_yaw(orientation):
        """Convert quaternion to yaw angle (radians)"""
        siny_cosp = 2 * (orientation.w * orientation.z + orientation.x * orientation.y)
        cosy_cosp = 1 - 2 * (orientation.y**2 + orientation.z**2)
        return math.atan2(siny_cosp, cosy_cosp)

    def get_user_input(self):
        """Prompt user for target pose and mode with validation"""
        while True:
            try:
                print("\n=== Enter Target Pose ===")
                x = float(input("X coordinate: "))
                y = float(input("Y coordinate: "))
                yaw = float(input("Yaw angle (radians): "))
                mode = int(input("Control mode (0=sequential, 1=simultaneous): "))
                
                if mode not in (0, 1):
                    raise ValueError("Mode must be 0 or 1")
                return x, y, yaw, mode
                
            except ValueError as e:
                rospy.logwarn(f"Invalid input: {e}. Please try again.")

    def check_goal_reached(self, tolerance=0.1):
        """Check if current pose is within tolerance of target"""
        dx = self.target_pose['x'] - self.current_pose['x']
        dy = self.target_pose['y'] - self.current_pose['y']
        return math.hypot(dx, dy) < tolerance

    def run(self):
        """Main control loop"""
        while not rospy.is_shutdown():
            if self.goal_reached:
                # Get new target from user
                x, y, yaw, mode = self.get_user_input()
                self.target_pose.update({'x': x, 'y': y, 'yaw': yaw, 'mode': mode})
                
                # Publish target
                target_msg = Float64MultiArray()
                target_msg.data = [x, y, yaw, mode]
                self.pose_publisher.publish(target_msg)
                rospy.loginfo(f"Published new target: {target_msg.data}")
                self.goal_reached = False
            
            # Check goal status
            self.goal_reached = self.check_goal_reached()
            self.rate.sleep()

if __name__ == "__main__":
    try:
        planner = MotionPlanner()
        rospy.loginfo("Motion Planner initialized. Waiting for inputs...")
        planner.run()
    except rospy.ROSInterruptException:
        pass