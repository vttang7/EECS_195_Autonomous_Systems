#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray
import math

class PIDController:
    def __init__(self):
        # Initialize node and setup publishers/subscribers
        rospy.init_node('pid_controller')
        
        # ROS communication setup
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('/reference_pose', Float64MultiArray, self.ref_callback)
        rospy.Subscriber('/odom', Odometry, self.odom_callback)
        
        # Control parameters
        self.rate = rospy.Rate(10)  # 10 Hz control loop
        self.last_time = rospy.Time.now()
        
        # PID parameters - now organized in dictionaries for easier management
        self.pid_params = {
            'linear': {
                'kp': 2.0,
                'ki': 0.01,
                'kd': 0.4,
                'max_output': 0.7,
                'min_output': -0.7,
                'integral_limit': 1.0
            },
            'angular': {
                'kp': 4.0,
                'ki': 0.01,
                'kd': 0.6,
                'max_output': 1.5,
                'min_output': -1.5,
                'integral_limit': 1.0
            }
        }
        
        # State variables
        self.ref_pose = {'x': 0, 'y': 0, 'theta': 0, 'mode': 0}  # target pose
        self.curr_pose = {'x': 0, 'y': 0, 'theta': 0}  # current pose
        
        # PID control variables
        self.prev_errors = {'linear': 0, 'angular': 0}
        self.integral_errors = {'linear': 0, 'angular': 0}

    def ref_callback(self, msg):
        """Callback for reference pose updates"""
        self.ref_pose = {
            'x': msg.data[0],
            'y': msg.data[1],
            'theta': msg.data[2],
            'mode': msg.data[3]
        }

    def odom_callback(self, msg):
        """Callback for odometry updates"""
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        yaw = self.quaternion_to_yaw(ori.x, ori.y, ori.z, ori.w)
        
        self.curr_pose = {
            'x': pos.x,
            'y': pos.y,
            'theta': yaw
        }

    @staticmethod
    def quaternion_to_yaw(x, y, z, w):
        """Convert quaternion orientation to yaw angle"""
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        return math.atan2(siny_cosp, cosy_cosp)

    def calculate_errors(self):
        """Calculate current position and orientation errors"""
        # Position errors
        error_x = self.ref_pose['x'] - self.curr_pose['x']
        error_y = self.ref_pose['y'] - self.curr_pose['y']
        
        # Distance and angle to target
        distance = math.hypot(error_x, error_y)
        target_angle = math.atan2(error_y, error_x)
        
        # Angular error (normalized to [-pi, pi])
        error_theta = self.normalize_angle(target_angle - self.curr_pose['theta'])
        
        return distance, error_theta

    @staticmethod
    def normalize_angle(angle):
        """Normalize angle to [-pi, pi]"""
        return math.atan2(math.sin(angle), math.cos(angle))

    def compute_pid(self, error, prev_error, integral_error, pid_type):
        """Compute PID output for given error and PID type"""
        params = self.pid_params[pid_type]
        
        # Calculate time step
        current_time = rospy.Time.now()
        dt = (current_time - self.last_time).to_sec()
        self.last_time = current_time
        
        # Proportional term
        p = params['kp'] * error
        
        # Integral term with anti-windup
        self.integral_errors[pid_type] += error * dt
        self.integral_errors[pid_type] = max(-params['integral_limit'], min(params['integral_limit'], self.integral_errors[pid_type]))
        i = params['ki'] * self.integral_errors[pid_type]
        
        # Derivative term
        if dt > 0:
            d = params['kd'] * (error - prev_error) / dt
        else:
            d = 0
        
        # Compute output and apply limits
        output = p + i + d
        output = max(params['min_output'], min(params['max_output'], output))
        
        # Apply deadzone for very small outputs
        if abs(output) < 0.05:
            output = 0.0
            
        return output

    def control_sequence_mode0(self, distance, error_theta):
        """Control sequence for mode 0 (rotate then move)"""
        cmd = Twist()
        final_error = self.normalize_angle(self.ref_pose['theta'] - self.curr_pose['theta'])
        
        if abs(error_theta) > 0.05:
            # Rotate to face target
            cmd.angular.z = self.compute_pid(error_theta, self.prev_errors['angular'], self.integral_errors['angular'], 'angular')
        elif distance > 0.1:
            # Move toward target
            cmd.linear.x = self.compute_pid(distance, self.prev_errors['linear'], self.integral_errors['linear'], 'linear')
        else:
            # Final orientation adjustment
            if abs(final_error) > 0.05:
                cmd.angular.z = self.compute_pid(final_error, self.prev_errors['angular'], self.integral_errors['angular'], 'angular')
            else:
                # Reset integral terms when target is reached
                self.integral_errors = {'linear': 0, 'angular': 0}
                
        return cmd

    def control_sequence_mode1(self, distance, error_theta):
        """Control sequence for mode 1 (rotate and move simultaneously)"""
        cmd = Twist()
        final_error = self.normalize_angle(self.ref_pose['theta'] - self.curr_pose['theta'])
        
        if distance > 0.1:
            # Combined movement and rotation
            cmd.linear.x = self.compute_pid(distance, self.prev_errors['linear'], self.integral_errors['linear'], 'linear')
            cmd.angular.z = self.compute_pid(error_theta, self.prev_errors['angular'], self.integral_errors['angular'], 'angular')
            
            # Apply scaling factors based on conditions
            angle_penalty = max(0.0, 1.0 - abs(error_theta))
            cmd.linear.x *= angle_penalty
            
            if distance < 0.5:
                cmd.linear.x *= distance / 0.5
                
            if abs(error_theta) < 0.5:
                cmd.angular.z *= abs(error_theta) / 0.5
        else:
            # Final orientation adjustment
            if abs(final_error) > 0.05:
                cmd.angular.z = self.compute_pid(final_error, self.prev_errors['angular'], self.integral_errors['angular'], 'angular')
            else:
                # Reset integral terms when target is reached
                self.integral_errors = {'linear': 0, 'angular': 0}
                
        return cmd

    def control(self):
        """Main control function"""
        # Calculate current errors
        distance, error_theta = self.calculate_errors()
        
        # Select control mode
        if self.ref_pose['mode'] == 0:
            cmd = self.control_sequence_mode0(distance, error_theta)
        else:
            cmd = self.control_sequence_mode1(distance, error_theta)
            
        # Publish command
        self.cmd_vel_pub.publish(cmd)
        
        # Update previous errors
        self.prev_errors = {
            'linear': distance,
            'angular': error_theta
        }

    def run(self):
        """Main loop"""
        while not rospy.is_shutdown():
            self.control()
            self.rate.sleep()

if __name__ == "__main__":
    try:
        controller = PIDController()
        controller.run()
    except rospy.ROSInterruptException:
        pass