#!/usr/bin/env python3
import rospy
import numpy as np
import cv2
import os
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Float64MultiArray
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from rrt import rrt_pathfinder 

class RRTNode:
    def __init__(self):
        rospy.init_node('rrt_node', anonymous=True)
        
        # Map parameters
        self.map_img = None
        self.resolution = None
        self.origin = None
        
        # Publishers and Subscribers
        self.trajectory_pub = rospy.Publisher('/trajectory', Float64MultiArray, queue_size=10)
        rospy.Subscriber('/map', OccupancyGrid, self.map_callback)
        rospy.Subscriber('/start_goal', Float64MultiArray, self.start_goal_callback)
        
        rospy.loginfo("RRT node initialized. Waiting for /map and /start_goal...")

    def occupancygrid_to_image(self, msg):
        """Convert OccupancyGrid message to image format"""
        self.resolution = msg.info.resolution
        self.origin = [msg.info.origin.position.x, msg.info.origin.position.y]
        width, height = msg.info.width, msg.info.height

        data = np.array(msg.data).reshape((height, width))
        img = np.full_like(data, 255, dtype=np.uint8)
        img[data == -1] = 127  # unknown
        img[data == 100] = 0   # occupied
        self.map_img = np.flipud(img)  # Flip to match image coordinates

    def map_callback(self, msg):
        """Handle incoming map data"""
        self.occupancygrid_to_image(msg)
        rospy.loginfo_once("Map received and converted.")

    def start_goal_callback(self, msg):
        """Handle start and goal positions and compute path"""
        if self.map_img is None:
            rospy.logwarn("Map not yet received. Ignoring goal.")
            return

        try:
            # Extract start and goal positions
            x_start, y_start, x_goal, y_goal = msg.data
            start, goal = [x_start, y_start], [x_goal, y_goal]
            rospy.loginfo(f"Received start: {start}, goal: {goal}")

            # Compute path using RRT
            _, _, path_px, path_world = rrt_pathfinder(
                start, goal, self.map_img, self.resolution, self.origin
            )

            # Publish trajectory
            self.publish_trajectory(path_world)
            
            # Visualize and save path
            self.visualize_path(path_px)
            
        except Exception as e:
            rospy.logerr(f"RRT pathfinding failed: {e}")

    def publish_trajectory(self, path_world):
        """Publish the computed path as trajectory"""
        flat_path = [coord for point in path_world for coord in point]
        traj_msg = Float64MultiArray(data=flat_path)
        self.trajectory_pub.publish(traj_msg)
        rospy.loginfo("Trajectory published.")

    def visualize_path(self, path_px):
        """Draw path on map and save to file"""
        drawn_img = self.map_img.copy()
        
        # Draw path lines
        for i in range(1, len(path_px)):
            pt1 = tuple(map(int, path_px[i - 1]))
            pt2 = tuple(map(int, path_px[i]))
            cv2.line(drawn_img, pt1, pt2, color=150, thickness=2)
        
        # Save image
        output_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "..", "..", "..", "my_map_output.pgm"
        )
        cv2.imwrite(output_path, drawn_img)
        rospy.loginfo(f"Path image saved at {output_path}")

    def run(self):
        rospy.spin()

if __name__ == '__main__':
    try:
        node = RRTNode()
        node.run()
    except rospy.ROSInterruptException:
        pass