#!/usr/bin/env python3

import rospy
from std_msgs.msg import Float64MultiArray
import random
from typing import List, Optional

class MotionPlanner:
    def __init__(self):
        self.trajectory_received = False
        rospy.init_node('motion_planner', anonymous=True)
        
        # Publishers and Subscribers
        self.start_goal_pub = rospy.Publisher('/start_goal', Float64MultiArray, queue_size=10)
        rospy.Subscriber('/trajectory', Float64MultiArray, self.trajectory_callback)
        
        # Configuration
        self.workspace_bounds = {
            'xmin': -10, 'xmax': 9,
            'ymin': -10, 'ymax': 9
        }
        
        rospy.sleep(1)  # Allow time for setup

    def trajectory_callback(self, msg: Float64MultiArray) -> None:
        """Callback to process and display received trajectories"""
        self.trajectory_received = True
        path = msg.data
        print("\n--- Received Trajectory ---")
        for i in range(0, len(path), 2):
            print(f"  Point {i//2}: ({path[i]:.2f}, {path[i+1]:.2f})")

    def get_user_coordinates(self) -> List[float]:
        """Get start and goal coordinates from user input"""
        print("\nEnter Start and Goal Coordinates (in meters):")
        while True:
            try:
                x_start = float(input("Start x: "))
                y_start = float(input("Start y: "))
                x_goal = float(input("Goal x: "))
                y_goal = float(input("Goal y: "))
                return [x_start, y_start, x_goal, y_goal]
            except ValueError:
                print("Invalid input. Please enter numeric values.")

    def generate_random_coordinates(self) -> List[float]:
        """Generate random start and goal coordinates within workspace bounds"""
        coords = [
            random.uniform(self.workspace_bounds['xmin'], self.workspace_bounds['xmax']),
            random.uniform(self.workspace_bounds['ymin'], self.workspace_bounds['ymax']),
            random.uniform(self.workspace_bounds['xmin'], self.workspace_bounds['xmax']),
            random.uniform(self.workspace_bounds['ymin'], self.workspace_bounds['ymax'])
        ]
        print(f"\nRandom Start: ({coords[0]:.2f}, {coords[1]:.2f})")
        print(f"Random Goal:  ({coords[2]:.2f}, {coords[3]:.2f})")
        return coords

    def display_menu(self) -> Optional[str]:
        """Display user menu and get selection"""
        print("\n--- Motion Planner UI ---")
        print("Choose an option:")
        print("  1. Manually enter start/goal")
        print("  2. Use randomly generated start/goal")
        print("  q. Quit")
        return input("Enter your choice (1/2/q): ").strip().lower()

    def publish_coordinates(self, coords: List[float]) -> None:
        """Publish coordinates to /start_goal topic"""
        msg = Float64MultiArray(data=coords)
        self.trajectory_received = False
        self.start_goal_pub.publish(msg)
        print("\nSent start and goal to /start_goal. Waiting for trajectory...")

    def wait_for_trajectory(self) -> None:
        """Wait until trajectory is received or node is shutdown"""
        rate = rospy.Rate(10)  # 10Hz
        while not rospy.is_shutdown() and not self.trajectory_received:
            rate.sleep()

    def run(self) -> None:
        """Main execution loop"""
        while not rospy.is_shutdown():
            choice = self.display_menu()
            
            if choice == 'q':
                break
            
            if choice == '1':
                coords = self.get_user_coordinates()
            elif choice == '2':
                coords = self.generate_random_coordinates()
            else:
                print("Invalid choice. Please try again.")
                continue
            
            self.publish_coordinates(coords)
            self.wait_for_trajectory()

if __name__ == '__main__':
    try:
        planner = MotionPlanner()
        planner.run()
    except rospy.ROSInterruptException:
        pass