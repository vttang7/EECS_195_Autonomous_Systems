#!/usr/bin/env python3
import rospy
import numpy as np
import cv2
import os
import sys
from typing import List, Tuple, Optional

# Ensure rrt.py is accessible
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rrt import rrt_pathfinder

from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Float64MultiArray

class RRTNode:
    def __init__(self):
        rospy.init_node('rrt_node')
        
        # Map properties
        self.map_img: Optional[np.ndarray] = None
        self.resolution: float = 0.0
        self.origin: List[float] = [0.0, 0.0]
        self.inflation_radius: int = 4  # pixels
        
        # ROS communication
        self.trajectory_pub = rospy.Publisher('/trajectory', Float64MultiArray, queue_size=10)
        rospy.Subscriber('/map', OccupancyGrid, self.map_callback)
        rospy.Subscriber('/start_goal', Float64MultiArray, self.start_goal_callback)
        
        rospy.loginfo("RRT node initialized. Waiting for /map and /start_goal...")

    def map_callback(self, msg: OccupancyGrid) -> None:
        """Process incoming map message and convert to image format"""
        self.resolution = msg.info.resolution
        self.origin = [msg.info.origin.position.x, msg.info.origin.position.y]
        width = msg.info.width
        height = msg.info.height

        # Convert occupancy grid to image (0=occupied, 127=unknown, 255=free)
        data = np.array(msg.data).reshape((height, width))
        self.map_img = np.full_like(data, 255, dtype=np.uint8)
        self.map_img[data == -1] = 127  # unknown
        self.map_img[data == 100] = 0   # occupied
        self.map_img = np.flipud(self.map_img)  # Flip to align with image coordinates
        
        rospy.loginfo("Map received and converted.")

    def inflate_obstacles(self) -> np.ndarray:
        """Create a copy of the map with inflated obstacles"""
        if self.map_img is None:
            raise ValueError("Map not available for inflation")
            
        inflated_map = self.map_img.copy()
        occupied_indices = np.argwhere(self.map_img == 0)
        
        for y, x in occupied_indices:
            cv2.circle(inflated_map, (x, y), self.inflation_radius, 0, -1)
            
        return inflated_map

    def is_segment_valid(self, p1: Tuple[float, float], p2: Tuple[float, float], 
                        map_img: np.ndarray) -> bool:
        """Check if line segment between p1 and p2 is collision-free"""
        line_pts = np.linspace(p1, p2, num=int(np.hypot(p2[0]-p1[0], p2[1]-p1[1]))*2)
        
        for pt in line_pts:
            x, y = map(int, pt)
            if not (0 <= y < map_img.shape[0] and 0 <= x < map_img.shape[1]):
                return False
            if map_img[y, x] != 255:
                return False
        return True

    def validate_path(self, path_px: List[Tuple[float, float]], 
                     path_world: List[Tuple[float, float]],
                     map_img: np.ndarray) -> Tuple[List[Tuple[float, float]], List[Tuple[float, float]]]:
        """Validate and filter the raw path"""
        # First pass: Check individual points
        valid_px, valid_world = [], []
        for (px, py), (wx, wy) in zip(path_px, path_world):
            if (0 <= int(py) < map_img.shape[0] and 0 <= int(px) < map_img.shape[1] and
                map_img[int(py), int(px)] == 255):
                valid_px.append((px, py))
                valid_world.append((wx, wy))
            else:
                rospy.logwarn(f"Invalid path point {(px, py)} - skipping")

        if not valid_px:
            raise ValueError("No valid path points found")

        # Second pass: Check segments between points
        final_px = [valid_px[0]]
        final_world = [valid_world[0]]
        for i in range(1, len(valid_px)):
            if self.is_segment_valid(valid_px[i-1], valid_px[i], map_img):
                final_px.append(valid_px[i])
                final_world.append(valid_world[i])
            else:
                rospy.logwarn(f"Invalid segment from {valid_px[i-1]} to {valid_px[i]}")
                break

        if len(final_px) < 2:
            raise ValueError("No valid path segments found")

        return final_px, final_world

    def save_path_image(self, path_px: List[Tuple[float, float]]) -> None:
        """Save the path visualization to an image file"""
        if self.map_img is None:
            return
            
        drawn_img = self.map_img.copy()
        for i in range(1, len(path_px)):
            pt1 = tuple(map(int, path_px[i-1]))
            pt2 = tuple(map(int, path_px[i]))
            cv2.line(drawn_img, pt1, pt2, color=150, thickness=2)

        output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "rrt_path_output.pgm")
        cv2.imwrite(output_path, drawn_img)
        rospy.loginfo(f"Path visualization saved to {output_path}")

    def start_goal_callback(self, msg: Float64MultiArray) -> None:
        """Handle start/goal messages and initiate path planning"""
        if self.map_img is None:
            rospy.logwarn("Map not received - ignoring start/goal")
            return

        try:
            # Parse start and goal positions
            x_start, y_start, x_goal, y_goal = msg.data
            start = (x_start, y_start)
            goal = (x_goal, y_goal)
            rospy.loginfo(f"Planning path from {start} to {goal}")

            # Inflate obstacles for safer planning
            inflated_map = self.inflate_obstacles()

            # Generate raw path using RRT
            start_px, goal_px, raw_path_px, raw_path_world = rrt_pathfinder(
                start, goal, inflated_map, self.resolution, self.origin)

            # Validate and filter the path
            valid_path_px, valid_path_world = self.validate_path(
                raw_path_px, raw_path_world, inflated_map)

            # Publish the validated trajectory
            flat_path = []
            for x, y in valid_path_world:
                flat_path.extend([x, y])
                
            traj_msg = Float64MultiArray(data=flat_path)
            self.trajectory_pub.publish(traj_msg)
            rospy.loginfo(f"Published trajectory with {len(valid_path_world)} waypoints")

            # Save visualization
            self.save_path_image(valid_path_px)

        except Exception as e:
            rospy.logerr(f"Path planning failed: {str(e)}")

    def run(self) -> None:
        """Main node execution"""
        rospy.spin()

if __name__ == '__main__':
    try:
        node = RRTNode()
        node.run()
    except rospy.ROSInterruptException:
        pass