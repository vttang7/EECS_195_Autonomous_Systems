#!/usr/bin/env python3
import rospy
import math
from std_msgs.msg import Float64MultiArray
from nav_msgs.msg import Odometry

class MotionPlanner:
    def __init__(self):
        """Initialize the motion planner node."""
        # Configuration parameters
        self.position_threshold = 0.1  # meters
        self.orientation_threshold = 0.1  # radians
        self.control_rate = 10  # Hz

        # State variables
        self.current_pose = [0.0, 0.0, 0.0]  # x, y, theta
        self.trajectory = []
        self.current_waypoint_idx = 0
        self.goal_reached = True
        self.trajectory_received = False

        # Initialize ROS components
        self.initialize_ros_components()
        rospy.loginfo("Motion Planner Node initialized")

    def initialize_ros_components(self):
        """Set up ROS publishers and subscribers."""
        rospy.init_node("motion_planner", anonymous=True)
        self.start_goal_pub = rospy.Publisher("/start_goal", Float64MultiArray, queue_size=10)
        self.ref_pose_pub = rospy.Publisher("/reference_pose", Float64MultiArray, queue_size=10)
        rospy.Subscriber("/odom", Odometry, self.odom_callback)
        rospy.Subscriber("/trajectory", Float64MultiArray, self.trajectory_callback)

    def odom_callback(self, msg):
        """Update current pose from odometry data."""
        position = msg.pose.pose.position
        orientation = msg.pose.pose.orientation
        
        # Convert quaternion to yaw angle
        siny_cosp = 2 * (orientation.w * orientation.z + orientation.x * orientation.y)
        cosy_cosp = 1 - 2 * (orientation.y**2 + orientation.z**2)
        theta = math.atan2(siny_cosp, cosy_cosp)
        
        self.current_pose = [position.x, position.y, theta]

    def trajectory_callback(self, msg):
        """Process incoming trajectory message."""
        self.trajectory = []
        data = msg.data
        
        # Convert flat array to list of (x,y) waypoints
        for i in range(0, len(data), 2):
            self.trajectory.append((data[i], data[i+1]))
        
        rospy.loginfo(f"Received trajectory with {len(self.trajectory)} waypoints")
        self.current_waypoint_idx = 0
        self.goal_reached = False
        self.trajectory_received = True

    def is_waypoint_reached(self, waypoint):
        """Check if current pose is within threshold of target waypoint."""
        x, y = waypoint
        curr_x, curr_y, _ = self.current_pose
        distance = math.hypot(x - curr_x, y - curr_y)
        return distance < self.position_threshold

    def get_next_waypoint(self):
        """Retrieve the next waypoint in the trajectory."""
        if self.current_waypoint_idx < len(self.trajectory):
            return self.trajectory[self.current_waypoint_idx]
        return None

    def get_user_goal(self):
        """Prompt user for goal coordinates through terminal."""
        while True:
            try:
                rospy.loginfo("\nEnter Goal Coordinates:")
                goal_x = float(input("Goal x: "))
                goal_y = float(input("Goal y: "))
                return goal_x, goal_y
            except ValueError:
                rospy.logwarn("Invalid input. Please enter numbers.")

    def publish_start_goal(self, goal_x, goal_y):
        """Publish start and goal coordinates."""
        start_goal_msg = Float64MultiArray()
        start_goal_msg.data = [
            self.current_pose[0], self.current_pose[1],  # start x,y
            goal_x, goal_y                              # goal x,y
        ]
        self.start_goal_pub.publish(start_goal_msg)
        rospy.loginfo(f"Published start ({self.current_pose[0]:.2f}, {self.current_pose[1]:.2f}) to goal ({goal_x:.2f}, {goal_y:.2f})")

    def publish_reference_pose(self, waypoint):
        """Publish reference pose for the controller."""
        ref_pose_msg = Float64MultiArray()

        # Calculate desired orientation toward waypoint
        dx = waypoint[0] - self.current_pose[0]
        dy = waypoint[1] - self.current_pose[1]
        theta = math.atan2(dy, dx)

        ref_pose_msg.data = [waypoint[0], waypoint[1], theta, 0]  # mode 0 for position control
        self.ref_pose_pub.publish(ref_pose_msg)

    def execute_trajectory(self):
        """Execute the current trajectory."""
        waypoint = self.get_next_waypoint()

        if waypoint is None:
            # Final goal reached
            self.goal_reached = True
            rospy.loginfo("Final goal reached!")
            return

        # Publish current waypoint as reference
        self.publish_reference_pose(waypoint)

        # Check waypoint completion
        if self.is_waypoint_reached(waypoint):
            rospy.loginfo(f"Waypoint {self.current_waypoint_idx + 1}/{len(self.trajectory)} reached: {waypoint}")
            self.current_waypoint_idx += 1

    def run(self):
        """Main execution loop of the motion planner."""
        rate = rospy.Rate(self.control_rate)

        while not rospy.is_shutdown():
            if self.goal_reached:
                # Get new goal from user
                try:
                    goal_x, goal_y = self.get_user_goal()
                    self.publish_start_goal(goal_x, goal_y)

                    # Wait for trajectory
                    self.trajectory_received = False
                    while not rospy.is_shutdown() and not self.trajectory_received:
                        rate.sleep()

                    self.goal_reached = False
                except (ValueError, KeyboardInterrupt):
                    rospy.logwarn("Invalid input. Please try again.")
                    continue
            else:
                self.execute_trajectory()

            rate.sleep()

def main():
    planner = MotionPlanner()
    planner.run()

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        rospy.loginfo("Motion planner shutdown complete")