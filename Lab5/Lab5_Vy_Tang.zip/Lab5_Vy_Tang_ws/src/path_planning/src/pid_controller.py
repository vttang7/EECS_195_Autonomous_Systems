#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray

class PIDController:
    def __init__(self):
        """Initialize the PID controller with default parameters."""
        # PID Gains (tuned for mode 0)
        self.KP_LINEAR = 0.6
        self.KI_LINEAR = 0.0
        self.KD_LINEAR = 0.2

        self.KP_ANGULAR = 1.0
        self.KI_ANGULAR = 0.0
        self.KD_ANGULAR = 0.1

        # State variables
        self.current_pose = [0.0, 0.0, 0.0]  # x, y, θ
        self.goal_pose = [0.0, 0.0, 0.0, 0]  # xr, yr, θr, mode (fixed to 0)

        # PID error memory
        self.prev_lin_error = 0.0
        self.int_lin_error = 0.0
        self.prev_ang_error = 0.0
        self.int_ang_error = 0.0

        # Control parameters
        self.control_rate = 10  # Hz
        self.position_threshold = 0.1  # meters
        self.orientation_threshold = 0.05  # radians
        self.max_linear_vel = 0.7  # m/s
        self.max_angular_vel = 1.5  # rad/s
        self.deadzone_linear = 0.01  # m/s
        self.deadzone_angular = 0.05  # rad/s

        # Initialize ROS components
        self.initialize_ros()

    def initialize_ros(self):
        """Set up ROS publishers and subscribers."""
        rospy.init_node("pid_controller")
        self.cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        rospy.Subscriber("/odom", Odometry, self.odom_callback)
        rospy.Subscriber("/reference_pose", Float64MultiArray, self.goal_callback)
        rospy.loginfo("PID Controller (Mode 0) Initialized")

    def odom_callback(self, msg):
        """Update current pose from odometry data."""
        position = msg.pose.pose.position
        orientation = msg.pose.pose.orientation

        # Convert quaternion to yaw angle
        siny_cosp = 2 * (orientation.w * orientation.z + orientation.x * orientation.y)
        cosy_cosp = 1 - 2 * (orientation.y**2 + orientation.z**2)
        theta = math.atan2(siny_cosp, cosy_cosp)

        self.current_pose = [position.x, position.y, theta]

    def goal_callback(self, msg):
        """Update goal pose from reference pose message."""
        self.goal_pose = msg.data  # [xr, yr, θr, mode]

    def calculate_errors(self):
        """Compute position and orientation errors."""
        xr, yr, theta_r, _ = self.goal_pose
        x, y, theta = self.current_pose

        # Position error
        dx = xr - x
        dy = yr - y
        distance = math.hypot(dx, dy)
        
        # Orientation errors
        desired_theta = math.atan2(dy, dx)
        error_theta = math.atan2(math.sin(desired_theta - theta), math.cos(desired_theta - theta))
        final_error = math.atan2(math.sin(theta_r - theta), math.cos(theta_r - theta))

        return distance, error_theta, final_error

    def compute_pid(self, error, prev_error, int_error, kp, ki, kd, dt):
        """Compute PID output for a given error."""
        # Integral term
        int_error += error * dt
        
        # Derivative term
        d_error = (error - prev_error) / dt
        
        # PID output
        output = kp * error + ki * int_error + kd * d_error
        
        return output, int_error

    def apply_limits(self, cmd):
        """Apply velocity limits and deadzone to commands."""
        # Velocity limits
        cmd.linear.x = max(min(cmd.linear.x, self.max_linear_vel), -self.max_linear_vel)
        cmd.angular.z = max(min(cmd.angular.z, self.max_angular_vel), -self.max_angular_vel)

        # Deadzone
        if abs(cmd.angular.z) < self.deadzone_angular:
            cmd.angular.z = 0.0
        if abs(cmd.linear.x) < self.deadzone_linear:
            cmd.linear.x = 0.0

        return cmd

    def generate_control_command(self):
        """Generate the appropriate control command based on current state."""
        cmd = Twist()
        distance, error_theta, final_error = self.calculate_errors()
        dt = 1.0 / self.control_rate  # Time step

        # Mode 0: Position control (turn-then-move)
        if abs(error_theta) > self.orientation_threshold and distance > self.position_threshold:
            # Step 1: Rotate to face goal
            cmd.angular.z, self.int_ang_error = self.compute_pid(
                error_theta, self.prev_ang_error, self.int_ang_error,
                self.KP_ANGULAR, self.KI_ANGULAR, self.KD_ANGULAR, dt
            )
            cmd.linear.x = 0.0
        elif distance > self.position_threshold:
            # Step 2: Move forward
            cmd.linear.x, self.int_lin_error = self.compute_pid(
                distance, self.prev_lin_error, self.int_lin_error,
                self.KP_LINEAR, self.KI_LINEAR, self.KD_LINEAR, dt
            )
            cmd.angular.z = 0.0
        else:
            # Step 3: Adjust final orientation
            if abs(final_error) > self.orientation_threshold:
                cmd.angular.z = self.KP_ANGULAR * final_error
            cmd.linear.x = 0.0

        # Update error memory
        self.prev_lin_error = distance
        self.prev_ang_error = error_theta

        return self.apply_limits(cmd)

    def run(self):
        """Main control loop."""
        rate = rospy.Rate(self.control_rate)
        
        while not rospy.is_shutdown():
            cmd = self.generate_control_command()
            self.cmd_vel_pub.publish(cmd)
            rate.sleep()

def main():
    controller = PIDController()
    controller.run()

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        rospy.loginfo("PID Controller shutdown complete")