#!/usr/bin/env python3
import rospy
import numpy as np
import cv2
import os
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Float64MultiArray
from rrt import rrt_pathfinder

class RRTNode:
    def __init__(self):
        """Initialize the RRT path planning node."""
        self.map_image = None
        self.map_resolution = None
        self.map_origin = None
        self.map_width = None
        self.map_height = None
        
        self.initialize_ros_components()
        rospy.loginfo("RRT Path Planning Node initialized and ready")

    def initialize_ros_components(self):
        """Set up ROS publishers and subscribers."""
        rospy.init_node("rrt_planner", anonymous=True)
        self.trajectory_pub = rospy.Publisher("/trajectory", Float64MultiArray, queue_size=10)
        rospy.Subscriber("/map", OccupancyGrid, self.handle_map_update)
        rospy.Subscriber("/start_goal", Float64MultiArray, self.handle_start_goal)

    def handle_map_update(self, msg):
        """Process incoming map data and convert to image format."""
        self.process_occupancy_grid(msg)
        rospy.loginfo_once("Map data received and processed")

    def process_occupancy_grid(self, msg):
        """Convert OccupancyGrid message to a usable image format."""
        self.map_resolution = msg.info.resolution
        self.map_origin = [msg.info.origin.position.x, msg.info.origin.position.y]
        self.map_width, self.map_height = msg.info.width, msg.info.height

        data = np.array(msg.data).reshape((self.map_height, self.map_width))
        img = np.full_like(data, 255, dtype=np.uint8)  # Free space (white)
        img[data == -1] = 127  # Unknown space (gray)
        img[data == 100] = 0   # Occupied space (black)
        self.map_image = np.flipud(img)  # Adjust coordinate system

    def handle_start_goal(self, msg):
        """Process start and goal coordinates and compute path."""
        if not self.validate_map_available():
            return

        start, goal = self.parse_coordinates(msg)
        if start is None or goal is None:
            return

        try:
            path_data = self.compute_path(start, goal)
            self.publish_and_visualize_path(*path_data)
        except Exception as e:
            rospy.logerr(f"Path computation failed: {str(e)}")

    def validate_map_available(self):
        """Check if map data has been received."""
        if self.map_image is None:
            rospy.logwarn("Path computation skipped - no map data available")
            return False
        return True

    def parse_coordinates(self, msg):
        """Extract and validate start/goal coordinates from message."""
        if len(msg.data) != 4:
            rospy.logerr("Invalid coordinate message - expected 4 values")
            return None, None

        start = [msg.data[0], msg.data[1]]
        goal = [msg.data[2], msg.data[3]]
        rospy.loginfo(f"Planning path from {start} to {goal}")
        return start, goal

    def compute_path(self, start, goal):
        """Compute path using RRT algorithm."""
        return rrt_pathfinder(
            start, goal, 
            self.map_image, 
            self.map_resolution, 
            self.map_origin
        )

    def publish_and_visualize_path(self, start_px, goal_px, path_px, path_world):
        """Publish path and create visualization."""
        # Publish trajectory
        flat_path = [coord for point in path_world for coord in point]
        self.trajectory_pub.publish(Float64MultiArray(data=flat_path))
        rospy.loginfo(f"Published path with {len(path_world)} waypoints")

        # Visualize and save
        self.create_path_visualization(path_px)
        
    def create_path_visualization(self, path_px, filename="output_map.pgm"):
        """Draw path on map and save to file."""
        visual_map = self.map_image.copy()
        
        # Draw path segments
        for i in range(1, len(path_px)):
            start = tuple(map(int, path_px[i-1]))
            end = tuple(map(int, path_px[i]))
            cv2.line(visual_map, start, end, color=150, thickness=2)

        # Save to output file
        output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
        output_path = os.path.join(output_dir, filename)
        cv2.imwrite(output_path, visual_map)
        rospy.loginfo(f"Path visualization saved to {output_path}")

    def run(self):
        """Main execution loop."""
        rospy.spin()

if __name__ == "__main__":
    try:
        node = RRTNode()
        node.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("RRT node shutdown complete")